import pandas as pd
import json
import re
from pathlib import Path

# ========== CONFIGURATION ==========

# Input jsPsych CSV (the raw file saved by the browser)
INPUT_CSV = "ooo_1763434983261.csv"

# Output: cleaned triplet-level CSV for analysis
OUTPUT_TRIPLET_CSV = "ooo_1763434983261_triplets.csv"

# Output: legend mapping stim_id -> (curv, nv, ang)
OUTPUT_STIM_LEGEND_CSV = "stimulus_legend.csv"


# ========== HELPER FUNCTIONS ==========

def build_stimulus_legend():
    """
    Build a mapping from (curv, nv, ang) to a unique stim_id (0..26).

    We assume exactly 3 levels for each:
        curv in {0,1,2}
        nv   in {1,2,3}
        ang  in {45,90,135}

    The exact ordering doesn’t matter as long as it’s consistent.
    Here we use lexical ordering: sort by (curv, nv, ang).
    """
    CURV = [0, 1, 2]
    NV   = [1, 2, 3]
    ANG  = [45, 90, 135]

    rows = []
    stim_id = 0
    for c in CURV:
        for n in NV:
            for a in ANG:
                rows.append({
                    "stim_id": stim_id,
                    "curv": c,
                    "nv": n,
                    "ang": a
                })
                stim_id += 1

    legend_df = pd.DataFrame(rows)
    # create dict for quick lookup: (curv, nv, ang) -> stim_id
    lookup = {
        (row.curv, row.nv, row.ang): int(row.stim_id)
        for row in legend_df.itertuples()
    }
    return legend_df, lookup


def extract_features_from_json(features_str):
    """
    Parse the 'features' column from jsPsych, which is stored as a JSON string.

    The string represents a list of 3 dicts, e.g.:
        '[{"curv":0,"nv":1,"ang":45}, {"curv":0,"nv":1,"ang":90}, {"curv":0,"nv":2,"ang":135}]'

    Returns a list of three dicts: [{'curv':..,'nv':..,'ang':..}, ...]
    or None if parsing fails.
    """
    if pd.isna(features_str):
        return None
    try:
        feats = json.loads(features_str)
        if not isinstance(feats, list) or len(feats) != 3:
            return None
        return feats
    except json.JSONDecodeError:
        return None


def parse_filename_features(filename):
    """
    Given a filename like:
        images/curv0/stim_nv2_ang135_curv0_rot+090.png

    Extract nv, ang, curv, rot using regex.

    Returns (curv, nv, ang, rot) or (None, None, None, None) if it fails.
    """
    if not isinstance(filename, str):
        return None, None, None, None

    # regex matches: stim_nv<NV>_ang<ANG>_curv<CURV>_rot<ROT>.png
    pattern = r"stim_nv(\d+)_ang(\d+)_curv(\d+)_rot([+-]\d{3})\.png$"
    m = re.search(pattern, filename)
    if m:
        nv = int(m.group(1))
        ang = int(m.group(2))
        curv = int(m.group(3))
        rot = m.group(4)
        return curv, nv, ang, rot
    else:
        return None, None, None, None


# ========== MAIN PROCESSING ==========

def main():
    # 1. Load the raw jsPsych CSV
    input_path = Path(INPUT_CSV)
    if not input_path.exists():
        raise FileNotFoundError(f"Input CSV not found: {INPUT_CSV}")

    print(f"Loading raw jsPsych CSV: {INPUT_CSV}")
    df = pd.read_csv(input_path)

    # 2. Build the stimulus legend and lookup
    legend_df, stim_lookup = build_stimulus_legend()
    print("Stimulus legend:")
    print(legend_df.head())

    # Save legend once (optional but useful)
    legend_df.to_csv(OUTPUT_STIM_LEGEND_CSV, index=False)
    print(f"Saved stimulus legend to: {OUTPUT_STIM_LEGEND_CSV}")

    # 3. Filter to trials we care about for the main RDM
    #    - Exclude practice
    #    - Exclude catch
    #    - Keep only exp_221 and exp_111
    #    (You can later change this if you decide to include practice or use catch for something else.)

    # Some jsPsych exports boolean columns as strings; normalize them
    def to_bool_safe(x):
        if isinstance(x, bool):
            return x
        if isinstance(x, str):
            return x.lower() == "true"
        return False

    if "is_practice" in df.columns:
        df["is_practice_bool"] = df["is_practice"].apply(to_bool_safe)
    else:
        df["is_practice_bool"] = False

    if "is_catch" in df.columns:
        df["is_catch_bool"] = df["is_catch"].apply(to_bool_safe)
    else:
        df["is_catch_bool"] = False

    # trial_kind column should have values like 'exp_221', 'exp_111', 'catch', 'practice_112'
    valid_kinds = {"exp_221", "exp_111"}
    mask_main = (
        (~df["is_practice_bool"]) &
        (~df["is_catch_bool"]) &
        (df["trial_kind"].isin(valid_kinds))
    )

    df_main = df.loc[mask_main].copy()
    print(f"Total rows in raw CSV: {len(df)}")
    print(f"Rows kept for main triplet analysis: {len(df_main)}")

    # 4. For each row, extract the 3 abstract feature triples from 'features'
    triplet_rows = []

    for row in df_main.itertuples():
        # Parse features JSON
        feats = extract_features_from_json(row.features)
        if feats is None:
            # In case something goes wrong, you can skip or raise an error
            # Here we skip and warn
            print(f"Warning: could not parse features JSON for trial_index={row.trial_index}")
            continue

        # feats is [ {curv:..., nv:..., ang:...}, ... ] for three stimuli
        # Convert each to a stim_id using the legend
        try:
            stim1_id = stim_lookup[(int(feats[0]["curv"]), int(feats[0]["nv"]), int(feats[0]["ang"]))]
            stim2_id = stim_lookup[(int(feats[1]["curv"]), int(feats[1]["nv"]), int(feats[1]["ang"]))]
            stim3_id = stim_lookup[(int(feats[2]["curv"]), int(feats[2]["nv"]), int(feats[2]["ang"]))]
        except KeyError as e:
            print(f"Warning: feature triple not in legend for trial_index={row.trial_index}: {e}")
            continue

        # Determine which stimulus was chosen
        # We already have 'chosen_stimulus' column in the jsPsych data
        chosen_file = getattr(row, "chosen_stimulus", None)
        curv_c, nv_c, ang_c, rot_c = parse_filename_features(chosen_file)

        if curv_c is None:
            print(f"Warning: could not parse chosen_stimulus filename for trial_index={row.trial_index}")
            choice_id = None
        else:
            # map chosen feature triple to stim_id
            choice_id = stim_lookup.get((curv_c, nv_c, ang_c), None)

        # choice_index is the position (0,1,2) of the clicked button
        choice_index = getattr(row, "response", None)  # jsPsych calls it 'response'
        rt = getattr(row, "rt", None)

        # You can define subj_id as a column in jsPsych, or derive from filename
        subj_id = getattr(row, "participant", None) if "participant" in df.columns else None

        triplet_rows.append({
            "subj_id": subj_id,
            "block_index": row.block_index,
            "trial_in_block": row.trial_in_block,
            "global_trial_index": row.global_trial_index,
            "trial_kind": row.trial_kind,
            "pattern": row.pattern,
            "stim1_id": stim1_id,
            "stim2_id": stim2_id,
            "stim3_id": stim3_id,
            "choice_index": choice_index,
            "choice_id": choice_id,
            "rt": rt
        })

    triplet_df = pd.DataFrame(triplet_rows)

    # 5. Save cleaned triplet-level CSV
    triplet_df.to_csv(OUTPUT_TRIPLET_CSV, index=False)
    print(f"Saved triplet-level CSV to: {OUTPUT_TRIPLET_CSV}")
    print(triplet_df.head())


if __name__ == "__main__":
    main()
