import pandas as pd
from itertools import combinations
from collections import Counter

TRIPLET_CSV = "ooo_1763434983261_triplets.csv"

# 1. Load triplet-level data
df = pd.read_csv(TRIPLET_CSV)

print("Number of trials in triplet CSV:", len(df))

# 2. For each trial, extract the 3 unordered pairs of stimulus IDs
pair_counts = Counter()

for row in df.itertuples():
    triplet = [row.stim1_id, row.stim2_id, row.stim3_id]
    # sort to get a canonical ordering within the pair
    for i, j in combinations(triplet, 2):
        pair = tuple(sorted((int(i), int(j))))
        pair_counts[pair] += 1

# 3. How many unique pairs did we see?
num_unique_pairs = len(pair_counts)
print("Number of unique unordered pairs observed:", num_unique_pairs)

# Total possible pairs for 27 stimuli (unordered: nCr(27,2))
N_STIM = 27
total_pairs = N_STIM * (N_STIM - 1) // 2
print("Total possible number of unordered pairs nCr(27, 2):", total_pairs)

# 4. Check coverage of full pair space
missing_pairs = total_pairs - num_unique_pairs
print(f"{missing_pairs} pairs were never seen in any triplet.")

# 5. Look at the distribution of how often pairs appear
counts = list(pair_counts.values())
print("min pair count:", min(counts))
print("max pair count:", max(counts))

# 6. Build a DataFrame with per-pair counts (for inspection / plotting)
pairs_df = (
    pd.DataFrame(
        [(i, j, c) for (i, j), c in pair_counts.items()],
        columns=["stim_i", "stim_j", "count"]
    )
    .sort_values("count")
)

# 7. Save pair coverage table for later inspection
pairs_df.to_csv("pair_coverage_ooo_1763434983261.csv", index=False)
print("\nSaved pair coverage to pair_coverage_ooo_1763434983261.csv")
